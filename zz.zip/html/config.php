<?php

//database login info
$dbuser = "ron";
$dbpw = "esBeny1337123!!!";
$db = "wp";
//Specific to you the store owner
$storeName = "AnonCoin";
$rootURL = "http://127.0.0.1/"; //example https://mysite.org  or http://yourhomepage.com/store
$yourEmail = "root@localhost";  //email notifications will be sent to this email when a new order is placed


//pw to access the admin pages
$adminPW = "AnonDemo";


//connect to the database
$conn = mysqli_connect("localhost", $dbuser, $dbpw, $db);
if(!$conn){
  die('Connection error check server log');
}

?>

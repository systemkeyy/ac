<?php

function rpcCall($ip, $port, $username, $password, $method, $params = []) {

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_URL, "http://$ip:$port/");
  curl_setopt($curl, CURLOPT_HTTPHEADER,
      array(
        "Content-Type: text/plain",
        "Authorization: Basic " . base64_encode($username . ":" . $password)
  ));
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode([
    "jsonrpc" => "1.0",
    "id" => "devfuturenow-php-rpc",
    "method" => $method,
    "params" => $params
  ]));

	$resp = curl_exec($curl);

	curl_close($curl);
	return json_decode($resp);
}

function toLog($txt) {
  global $path;
  echo "$txt\n";
  file_put_contents($path."/cookies/logs.log", $txt."\n", FILE_APPEND);
}
?>

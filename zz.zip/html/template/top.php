<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo $storeName; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!--<link rel="stylesheet" type="text/css" href="style.css">-->

  <style>
    body{
      background-color: rgba(17,24,39,1)!important;
      color:white!important;
    }
    .header_container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 25px 100px;
    }

    .header_logo_container img {
        height: 50px;
    }

    .header_nav_container {
        display: flex;
        align-items: center;
        gap: 40px;
    }

    .header_nav {
        display: flex;
        gap: 20px;
    }

    .header_nav_item {
        color: rgb(255 255 255 / 75%);
        transition: color .25s ease;
    }

    .header_nav_item:hover {
        color: rgb(255 255 255 / 100%);
        text-decoration: none!important;
    }

    .header_nav_login button {
      border: none;
        background-color: #6366f1;
        color: white;
        padding: 10px 20px;
        border-radius: 10px;
        transition: all .25s ease;
    }

    .header_nav_login button:hover {
        background-color: #7174f8;
        text-decoration: none!important;
    }

    .header_nav_cart svg {
        fill: #111827;
    }

    .header_nav_cart {
        background-color: #faa61a;
        padding: 20px;
        border-radius: 100%;
        transition: all .25s ease;
        height: 50px;
        width: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .header_nav_cart:hover {
        transform: scale(1.1);
        background-color: #ffb02d;
    }

    .header_nav_login {
        display: flex;
        color: white;
        align-items: center;
        gap: 10px;
    }


    #cartCont button {
        background: none;
        border: none;
    }

    #cartCost {
        position: absolute;
        right: -35px;
        color: #111827;
        background: #faa61a;
        padding: 2px 4px;
        border-radius: 100%;
        font-weight: bold;
    }

    #cartCont {
        position: relative;
    }

    #cartSpace {
        position: absolute;
        width: 208px;
        right: -80px;
        color: #111827;
        background: #faa61a;
        padding: 10px 20px;
        border-radius: 5px;
        top: 10px;
        z-index: 10;
        opacity: 0;
        pointer-events: none;
    }

    .header_nav_cart:hover #cartSpace {
        opacity: 1;
    }

    #cartHeader {display: none;}


    .img-container {
      margin-bottom: 10px;
      overflow: hidden;
    }

    .img-container img {
      width: 100%;
    }

    .product {
      padding-top: 20px;
      padding-bottom: 20px;
    }

    .status,
    .price {
      font-weight: 700;
    }

    .status,
    .text,
    .price {
      padding-bottom: 5px;
    }

    .status-span,
    .price-span {
      font-weight: normal;
    }

    .text {
      padding-bottom: 12px;
    }

    .picture-header {
      padding-bottom: 5px;
    }

    @media (max-width: 768px) {
      .img-container {
        height: auto;
      }

      .img-container img {
        height: 100%;
      }
    }
    #paymentInfo {
      width:300px;
      left:50%;
      top:50%;
      margin-left:-150px;
      margin-top:-150px;
      position:absolute;
      z-index:999;
      padding:15px;
      background: #fff;
      border:1px dashed #111;
    }
  </style>
  <script>
  function loopCheckTX(prod) {
    setTimeout(async function() {
      const check = await $.get(window.location.pathname+"?checktx="+prod.valuebuy);
      console.log("check",check);
      if (check.indexOf("yes") !== -1) {
        $("#paymentInfo .pending").hide();
        $("#paymentInfo .success").show();
        $("#paymentInfo .success .product").html('<h2>'+prod.title+'</h2><div class="status">STATUS : <span class="status-span">'+prod.status+'</span></div><div class="price">PRICE : <span class="price-span">'+prod.price+'</span></div><div class="picture-header">'+prod.imgtxt+'</div><div class="img-container">  <img src="'+prod.img+'" alt=""></div><div class="wrapper">  <div class="text">'+prod.desc+'</div>  <button class="btn btn-success btn-block btn-buy">BUY</button></div>');
      } else {
        loopCheckTX(prod);
      }
    }, 3000);
  }
  const decodeBase64 = function(s) {
    if (!s)
      return "";
    var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
    var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for(i=0;i<64;i++){e[A.charAt(i)]=i;}
    for(x=0;x<L;x++){
        c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
        while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
    }
    return r;
  };
  const startTimer = function() {
     $('#paymentInfo span.time').text(--sec);
     if (sec == 0) {
        $('#paymentInfo').fadeOut('fast');
        clearInterval(timer);
     }
  }

  $(document).ready(async function() {
      let exchangeRate = await $.getJSON( "https://api.coindesk.com/v1/bpi/currentprice/usd.json");
      exchangeRate = parseFloat(exchangeRate.bpi.USD.rate_float);
      $(document).click(function(e) {
          var container = $("#paymentInfo");
          if (!container.is(e.target) && container.has(e.target).length === 0 && !$(e.target).hasClass("btn-buy")) {
          console.log("e.target",e.target);
              container.hide();
          }
      });

      $( ".btn-buy" ).click(async function() {
        const el = $(this).parent().parent().find('.metadata').attr("value");
        let meta = JSON.parse(decodeBase64(el));
        if (meta.id >= 0) {
          $("#paymentInfo").show();
          const addr = await $.get(window.location.pathname+"?address");
          $("#paymentInfo .address").val(addr);
          $("#paymentInfo .value").val((meta.priceval / exchangeRate).toFixed(8));
          meta.valuebuy = (meta.priceval / exchangeRate).toFixed(8);
          timer = setInterval(startTimer, 1000);
          loopCheckTX(meta);
        }
      });
  });

  var sec = 60*60*2;
  var timer;
  </script>
  <style>
    .img-container {
      margin-bottom: 10px;
      overflow: hidden;
    }

    .img-container img {
      width: 100%;
    }

    .product {
      padding-top: 20px;
      padding-bottom: 20px;
    }

    .status,
    .price {
      font-weight: 700;
    }

    .status,
    .text,
    .price {
      padding-bottom: 5px;
    }

    .status-span,
    .price-span {
      font-weight: normal;
    }

    .text {
      padding-bottom: 12px;
    }

    .picture-header {
      padding-bottom: 5px;
    }

    @media (max-width: 768px) {
      .img-container {
        height: auto;
      }

      .img-container img {
        height: 100%;
      }
    }
    #paymentInfo {
      width:300px;
      left:50%;
      top:50%;
      margin-left:-150px;
      margin-top:-150px;
      position:absolute;
      z-index:999;
      padding:15px;
      background: #fff;
      border:1px dashed #111;
    }
  </style>
</head>

<body>
  <div id="paymentInfo" style="display:none">
    <div class="pending">
      Please procced with the payment to the following details:<br><br>
      Value: <input type="text" class="value" value=""/><br>
      Address: <input type="text" class="address" value=""/><br><br>
      <div style="text-align:center">Confirming...</div>
      <div style="text-align:center">Time left: <span class="time">0</span>secs</div>
    </div>
    <div class="success" style="display:none">
      Congratulations, you've bought the following product:<br>
      <div class="product">

      </div>
    </div>
  </div>
  
  <div class="header_container">
    <div class="header_logo_container">
      <img src="../banner.svg">
    </div>
    <div class="header_nav_container">
      <div class="header_nav">
        <a class="header_nav_item" href="../">Home</a>
        <a class="header_nav_item" href="../about/index.html">About us</a>
        <a class="header_nav_item" href="../contact/index.html">Contact</a>
      </div>
      <div class="header_nav_login">


<?php if ($_SESSION['email']) { ?>
      <form class="login-form" name="login_form" id="login_form" method="post" action="logout.php">
        Hello, <?php echo $_SESSION['email']; ?>!
        <button>log-Out</button>
      </form>
    <?php } else { ?>
      <span>Hello, Guest!</span>
    <?php } ?>
  </form>
      </div>
      <div class="header_nav_cart">
        <div id="cartCont">
           <div id="cartHeader">Your Cart</div>
            <div id="cartSpace">

          <?php
         $usdOwed = 0;
          for($i=0; $i<$cartItems; $i++)
          {
          $queryLoopCart = "SELECT * FROM products WHERE id = '$cart[$i]'";
          $doLoopCart = mysqli_query($conn, $queryLoopCart);
          $rowLoopCart = mysqli_fetch_assoc($doLoopCart);
          $loopName = $rowLoopCart['name'];
          $loopPrice = $rowLoopCart['price'];
          $usdOwed += $loopPrice;
          echo $loopName."<span class='cartPrice'>$".$loopPrice."</span>";
          echo"<br><br>";
          }

          echo "</div>";
          echo "<div id='cartCost'>$".$usdOwed."</div>";

        ?>
           <form action="cart.php">
              <button type="submit">
                <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0 0 24 24">    <path d="M 4.4160156 1.9960938 L 1.0039062 2.0136719 L 1.0136719 4.0136719 L 3.0839844 4.0039062 L 6.3789062 11.908203 L 5.1816406 13.822266 C 4.3432852 15.161017 5.3626785 17 6.9414062 17 L 19 17 L 19 15 L 6.9414062 15 C 6.8301342 15 6.8173041 14.978071 6.8769531 14.882812 L 8.0527344 13 L 15.521484 13 C 16.247484 13 16.917531 12.605703 17.269531 11.970703 L 20.871094 5.484375 C 21.242094 4.818375 20.760047 4 19.998047 4 L 5.25 4 L 4.4160156 1.9960938 z M 7 18 A 2 2 0 0 0 5 20 A 2 2 0 0 0 7 22 A 2 2 0 0 0 9 20 A 2 2 0 0 0 7 18 z M 17 18 A 2 2 0 0 0 15 20 A 2 2 0 0 0 17 22 A 2 2 0 0 0 19 20 A 2 2 0 0 0 17 18 z"></path></svg>
              </button>
            </form>
        </div>
        
      </div>
    </div>
  </div>
